export default {
    logoPath: "./static/images/logo.jpg"
}