<template>
  <div>Personal</div>
</template>
<script>
export default {
  name: "Personal",
  components: {},
  props: {},
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  created() {},
  mounted() {}
};
</script>
<style lang="less" scoped>
</style>