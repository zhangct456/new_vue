<template>
  <div>HostManage</div>
</template>
<script>
export default {
  name: "HostManage",
  components: {},
  props: {},
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  created() {},
  mounted() {}
};
</script>
<style lang="less" scoped>
</style>