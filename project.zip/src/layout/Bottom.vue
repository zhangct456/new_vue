<template>
  <div class="bottom">当前用户：主机超级管理员</div>
</template>

<script>
export default {
  name: "Bottom",
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {},
  created() {},
  mounted() {},
  watch: {},
  methods: {}
};
</script>

<style lang="less" scoped>
.bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  font-size: 12px;
  height: 25px;
  line-height: 25px;
  padding: 0 24px;
  color: white;
  background-color: #193c64;
}
</style>