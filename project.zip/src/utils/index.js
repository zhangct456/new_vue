// 判断dom是否相互包含
import domIsChild from "./domIsChild";

export { domIsChild };